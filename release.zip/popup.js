// popup.js - BlockForge popup controller

const shell       = document.getElementById('shell');
const toggle      = document.getElementById('toggle');
const toggleSt    = document.getElementById('toggleStatus');
const btnReset    = document.getElementById('btnReset');
const counterMain = document.getElementById('counterMain');
const counterAds  = document.getElementById('counterAds');
const counterTrk  = document.getElementById('counterTrackers');
const counterSess = document.getElementById('counterSessions');
const tabHostname = document.getElementById('tabHostname');
const tabTotal    = document.getElementById('tabTotal');
const tabAds      = document.getElementById('tabAds');
const tabTrackers = document.getElementById('tabTrackers');
const feed        = document.getElementById('feed');
const feedHint    = document.getElementById('feedHint');
const rulesInfo   = document.getElementById('rulesInfo');

let prevTotal = 0;

// --- number formatting ---

function fmt(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 10000)   return (n / 1000).toFixed(1) + 'k';
  return String(n);
}

// --- animated counter update ---

function setCounter(el, value, animate) {
  const cur = el.textContent;
  const next = fmt(value);
  if (cur === next) return;
  el.textContent = next;
  if (animate) {
    el.classList.remove('bump');
    void el.offsetWidth;
    el.classList.add('bump');
  }
}

// --- render state ---

function renderState(data) {
  const { enabled, stats, tabStats } = data;

  // Toggle
  toggle.checked = enabled;
  toggleSt.textContent = enabled ? 'ON' : 'OFF';
  shell.classList.toggle('disabled', !enabled);

  // Global counters
  const didIncrease = stats.total > prevTotal;
  setCounter(counterMain, stats.total, didIncrease);
  setCounter(counterAds, stats.ads, false);
  setCounter(counterTrk, stats.trackers, false);
  setCounter(counterSess, stats.sessions || 1, false);
  prevTotal = stats.total;

  // Tab stats
  const host = tabStats.hostname || '—';
  tabHostname.textContent = host;
  tabHostname.title = host;
  tabTotal.textContent = fmt(tabStats.total);
  tabAds.textContent = fmt(tabStats.ads);
  tabTrackers.textContent = fmt(tabStats.trackers);

  // Feed
  renderFeed(tabStats.lastSeen || []);
}

function renderFeed(items) {
  if (!items.length) {
    feedHint.textContent = 'no activity';
    feed.innerHTML = '<li class="feed-empty">nothing blocked yet on this page</li>';
    return;
  }

  feedHint.textContent = `last ${items.length}`;
  feed.innerHTML = '';

  for (const item of items) {
    const li = document.createElement('li');
    li.className = 'feed-item';

    const dot = document.createElement('span');
    dot.className = `feed-dot ${item.type}`;

    const host = document.createElement('span');
    host.className = 'feed-host';
    host.textContent = item.hostname;
    host.title = item.hostname;

    const type = document.createElement('span');
    type.className = `feed-type ${item.type}`;
    type.textContent = item.type === 'ad' ? 'AD' : 'TRK';

    li.append(dot, host, type);
    feed.appendChild(li);
  }
}

// --- load state ---

function loadState() {
  browser.runtime.sendMessage({ type: 'getState' }, data => {
    if (data) renderState(data);
  });
}

// --- load rules count ---

function loadRulesCount() {
  browser.runtime.sendMessage({ type: 'getRulesCount' }, data => {
    if (!data) return;
    const total = data.ads + data.trackers;
    rulesInfo.textContent = `${total.toLocaleString()} rules (${data.ads} ad / ${data.trackers} tracker)`;
  });
}

// --- events ---

toggle.addEventListener('change', () => {
  browser.runtime.sendMessage({ type: 'toggle' }, data => {
    if (!data) return;
    toggleSt.textContent = data.enabled ? 'ON' : 'OFF';
    shell.classList.toggle('disabled', !data.enabled);
  });
});

btnReset.addEventListener('click', () => {
  if (!confirm('Reset all statistics?')) return;
  browser.runtime.sendMessage({ type: 'resetStats' }, () => {
    loadState();
  });
});

// --- polling for live updates ---

loadState();
loadRulesCount();

const pollInterval = setInterval(loadState, 1500);
window.addEventListener('unload', () => clearInterval(pollInterval));
