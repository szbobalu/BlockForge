// rules.js - Wide-spectrum ad and tracker block list
// Sources: EasyList, EasyPrivacy, Peter Lowe's list, uBlock Origin compiled domains

const AD_DOMAINS = new Set([
  // Google Advertising
  "doubleclick.net",
  "googleadservices.com",
  "googlesyndication.com",
  "googletagservices.com",
  "adservice.google.com",
  "adservice.google.co.uk",
  "adservice.google.de",
  "adservice.google.fr",
  "pagead2.googlesyndication.com",
  "partnerads.google.com",
  "tpc.googlesyndication.com",
  // Amazon Ads
  "amazon-adsystem.com",
  "adsystem.amazon.com",
  "assoc-amazon.com",
  "fls-na.amazon.com",
  "mads.amazon-adsystem.com",
  // Outbrain / Taboola (content recommendation)
  "outbrain.com",
  "outbrainimg.com",
  "taboola.com",
  "trc.taboola.com",
  "cdn.taboola.com",
  // Criteo
  "criteo.com",
  "criteo.net",
  "hlserve.com",
  "hifipub.com",
  // AppNexus / Xandr
  "appnexus.com",
  "adnxs.com",
  "adnxs-simple.com",
  // Rubicon / Magnite
  "rubiconproject.com",
  "fastlane.rubiconproject.com",
  // PubMatic
  "pubmatic.com",
  "ads.pubmatic.com",
  // OpenX
  "openx.net",
  "openx.com",
  "servedby.openx.net",
  // Smaato
  "smaato.net",
  "smaato.com",
  // Smart AdServer
  "smartadserver.com",
  "sascdn.com",
  // Index Exchange
  "casalemedia.com",
  "indexexchange.com",
  "indexww.com",
  // The Trade Desk
  "thetradedesk.com",
  "adsrvr.org",
  "insight.adsrvr.org",
  // Media Math
  "mediamath.com",
  "mathtag.com",
  // Verizon / Oath / Yahoo
  "advertising.com",
  "adtech.de",
  "oath.com",
  "nexage.com",
  "brightroll.com",
  "adtechus.com",
  // Sharethrough
  "sharethrough.com",
  // GumGum
  "gumgum.com",
  // Revcontent
  "revcontent.com",
  "engageya.com",
  // Zedo
  "zedo.com",
  // Undertone
  "undertone.com",
  // YuMe
  "yume.com",
  // Teads
  "teads.tv",
  "teads.com",
  // JustPremium
  "justpremium.com",
  // Loopme
  "loopme.com",
  // Sovrn
  "sovrn.com",
  "lijit.com",
  // Sizmek (WPP)
  "sizmek.com",
  "serving-sys.com",
  // Flashtalking
  "flashtalking.com",
  // AdColony
  "adcolony.com",
  "adcolony.net",
  // Chartboost
  "chartboost.com",
  // MoPub / Twitter Ads
  "mopub.com",
  // SpotX
  "spotxchange.com",
  "spotx.tv",
  // FreeWheel
  "freewheel.tv",
  "freewheel.net",
  // E-Planning
  "e-planning.net",
  // Bidswitch
  "bidswitch.net",
  // Conversant
  "conversantmedia.com",
  "dotomi.com",
  // Tribal Fusion
  "tribalfusion.com",
  "exponential.com",
  // ValueClick
  "valueclick.com",
  "valueclick.net",
  // Specific SSPs
  "rhythmone.com",
  "1rx.io",
  "tidaltv.com",
  "videologygroup.com",
  "yieldmo.com",
  "emxdgt.com",
  "sonobi.com",
  "onetag.net",
  "onetag.com",
  "iqm.com",
  "iponweb.net",
  "lkqd.net",
  "lkqd.com",
  "kargo.com",
  "narrativ.com",
  "themediagrid.com",
  "springserve.com",
  "aerserv.com",
  "amobee.com",
  "freewheel.tv",
  "buysellads.com",
  "buysellads.net",
  "carbonads.com",
  "carbonads.net",
  "adzerk.net",
  "adzerk.com",
  "fastly-insights.com",
  "chango.com",
  "propellerads.com",
  "adblade.com",
  "adsnative.com",
  "adscale.de",
  "adswizz.com",
  "adtelligence.de",
  "adtng.com",
  "adverline.com",
  "adup-tech.com",
  "aerserv.com",
  "aolcdn.com",
  "trafficjunky.net",
  "yieldoptimizer.com",
  "zebestof.com",
  "zergnet.com",
  "viglink.com",
  "skimlinks.com",
  "genius.com/annotate.min.js",
  "netseer.com",
  "plista.com",
  "postrelease.com",
  "pro-market.net",
  "rhythmone.com",
  "rlcdn.com",
  "social.sprinklr.com",
  "strikead.com",
  "synacor.com",
  "tapad.com",
  "thinkrealtime.com",
  "vertamedia.com",
  "viant.com",
  "vidoomy.com",
  "visualdna.com",
  "w55c.net",
  "widdit.com",
  "xaxis.com",
  "xgraph.net",
  "zemanta.com",
  "smartclip.net",
  "smartclip.com",
  "snigelweb.com",
  "doubleverify.com",
  "adsafeprotected.com",
  "moat.com",
  "moatads.com",
  "moatpixel.com",
  "integralads.com",
  "ias.com",
  "pixalate.com",
  "forensiq.com",
  "confiant.com",
]);

const TRACKER_DOMAINS = new Set([
  // Google Analytics/Tag Manager
  "google-analytics.com",
  "analytics.google.com",
  "googletagmanager.com",
  "stats.g.doubleclick.net",
  // Facebook / Meta Pixel
  "connect.facebook.net",
  "facebook.net",
  "an.facebook.com",
  "pixel.facebook.com",
  // Twitter Analytics
  "t.co",
  "static.ads-twitter.com",
  "ads-twitter.com",
  "ads.twitter.com",
  "analytics.twitter.com",
  "syndication.twitter.com",
  // LinkedIn Insight
  "snap.licdn.com",
  "px.ads.linkedin.com",
  "ads.linkedin.com",
  "linkedin.com/analytics",
  // Pinterest Tag
  "ct.pinterest.com",
  "analytics.pinterest.com",
  // TikTok Pixel
  "analytics.tiktok.com",
  "ads.tiktok.com",
  // Hotjar
  "hotjar.com",
  "static.hotjar.com",
  "insights.hotjar.com",
  "vcv.hotjar.io",
  // Mixpanel
  "mixpanel.com",
  "api.mixpanel.com",
  "cdn.mxpnl.com",
  // Segment
  "segment.com",
  "segment.io",
  "api.segment.io",
  "cdn.segment.com",
  // Amplitude
  "amplitude.com",
  "api.amplitude.com",
  "cdn.amplitude.com",
  // Heap Analytics
  "heapanalytics.com",
  "cdn.heapanalytics.com",
  // FullStory
  "fullstory.com",
  "rs.fullstory.com",
  "edge.fullstory.com",
  // Mouseflow
  "mouseflow.com",
  "cdn.mouseflow.com",
  // CrazyEgg
  "crazyegg.com",
  "dnn506yrbagrg.cloudfront.net",
  // Kissmetrics
  "kissmetrics.com",
  "kissmetrics.io",
  // Optimizely
  "optimizely.com",
  "cdn.optimizely.com",
  "logx.optimizely.com",
  // Monetate
  "monetate.net",
  "monetate.com",
  // Clicktale
  "clicktale.net",
  "clicktale.com",
  // Smartlook
  "smartlook.com",
  "manager.smartlook.com",
  // Tealium
  "tealium.com",
  "tealiumiq.com",
  "tags.tiqcdn.com",
  "tiqcdn.com",
  // Snowplow
  "snowplow.io",
  "snowplowanalytics.com",
  // New Relic
  "newrelic.com",
  "nr-data.net",
  "js-agent.newrelic.com",
  // Dynatrace
  "dynatrace.com",
  "dynatrace-managed.com",
  // Comscore / ScorecardResearch
  "scorecardresearch.com",
  "comscore.com",
  // Nielsen
  "nielsen.com",
  "exelate.com",
  "exelator.com",
  "imrworldwide.com",
  // Quantcast
  "quantcast.com",
  "quantserve.com",
  // Bluekai (Oracle)
  "bluekai.com",
  "bkrtx.com",
  // Demdex (Adobe)
  "demdex.net",
  "omtrdc.net",
  "2o7.net",
  "everesttech.net",
  "everestads.net",
  // Lotame
  "lotame.com",
  "crwdcntrl.net",
  // LiveRamp
  "liveramp.com",
  "rlcdn.com",
  // Bombora
  "bombora.com",
  // Eyeota
  "eyeota.net",
  // Semasio
  "semasio.net",
  // Dstillery
  "dstillery.com",
  // Bizo (LinkedIn)
  "bizo.com",
  "bizographics.com",
  // AddThis
  "addthis.com",
  "addthisedge.com",
  // ShareThis
  "sharethis.com",
  "share.dmcdn.net",
  // Chartbeat
  "chartbeat.com",
  "chartbeat.net",
  "static.chartbeat.com",
  // Parse.ly
  "parsely.com",
  "api.parsely.com",
  "cdn.parsely.com",
  // SimpleReach
  "simplereach.com",
  // Hubspot
  "hubspot.com",
  "hs-analytics.net",
  "hsforms.com",
  "hubapi.com",
  "leadin.com",
  // Marketo
  "marketo.com",
  "mktoweb.com",
  "mkto-ab180176.com",
  // Eloqua (Oracle)
  "eloqua.com",
  "en25.com",
  // Salesforce / Pardot
  "pardot.com",
  "krxd.net",
  // Yandex Metrica
  "mc.yandex.ru",
  "mc.yandex.com",
  "an.yandex.ru",
  // StatCounter
  "statcounter.com",
  // Clicky
  "clicky.com",
  "static.getclicky.com",
  // Woopra
  "woopra.com",
  // Histats
  "histats.com",
  // Branch.io
  "branch.io",
  "app.link",
  // Adjust
  "adjust.com",
  "adjust.net",
  // AppsFlyer
  "appsflyer.com",
  // Kochava
  "kochava.com",
  // Singular
  "singular.net",
  // Permutive
  "permutive.com",
  "permutive.app",
  // Clearbit
  "clearbit.com",
  "cdn.clearbit.com",
  // Drift
  "drift.com",
  "js.driftt.com",
  // Intercom
  "intercomcdn.com",
  // Klaviyo
  "klaviyo.com",
  "a.klaviyo.com",
  // Lytics
  "lytics.io",
  "c.lytics.io",
  // Siteimprove
  "siteimprove.com",
  "siteimproveanalytics.com",
  "siteimproveanalytics.io",
  // Pingdom
  "pingdom.net",
  // Pendo
  "pendo.io",
  "cdn.pendo.io",
  // Gainsight
  "aptrinsic.com",
  // VWO (Visual Website Optimizer)
  "vwo.com",
  "visualwebsiteoptimizer.com",
  // Quora Pixel
  "quora.com",
  // Bing UET
  "bat.bing.com",
  // Microsoft Clarity
  "clarity.ms",
  "c.bing.com",
  // Algolia Insights
  "algolia.com",
  // Trustpilot Widgets
  "widget.trustpilot.com",
  // Yotpo
  "yotpo.com",
  // TrustArc
  "trustarc.com",
  "truste.com",
  // OneTrust
  "onetrust.com",
  "cookielaw.org",
  // Cookiebot
  "cookiebot.com",
  // ConsentManager
  "consentmanager.net",
  // UserCentrics
  "usercentrics.eu",
  // Bounce Exchange / BounceX
  "bouncex.com",
  "bouncex.net",
  "webeyez.com",
  // Liveperson
  "lpsnmedia.net",
  "liveperson.com",
  "liveperson.net",
  // Olark
  "olark.com",
  // Sumo
  "sumo.com",
  "sumo.ly",
  // OptinMonster
  "optinmonster.com",
  // PushCrew / VWO Engage
  "pushcrew.com",
  "pushengage.com",
  "pushly.com",
  "pushwoosh.com",
  "pushassist.com",
  // ContextWeb / Peer39
  "contextweb.com",
  "peer39.net",
  // Tynt
  "tynt.com",
  // Resonance
  "resonateinsights.com",
  // Dable
  "dable.io",
  // Retargetly
  "retargetly.com",
  // Sailthru
  "sailthru.com",
  // Sendgrid
  "sendgrid.net",
  "ct.sendgrid.net",
  // Mailchimp tracking
  "list-manage.com",
  // Wistia
  "wistia.com",
  "wi.st",
  // Convertkit
  "convertkit.com",
  "ck.convertkit.com",
  // Active Campaign
  "trackcmp.net",
  // Liveintent
  "liveintent.com",
  "liadm.com",
  // Parrable
  "parrable.com",
  // ID5
  "id5-sync.com",
  // Criteo UserID
  "hlserve.com",
  // Audigent
  "audigent.com",
  // Infomedia
  "agkn.com",
  // AlexaMetrics
  "alexametrics.com",
  // Weborama
  "weborama.com",
  "weborama.fr",
  // Digital Advertising Alliance
  "aboutads.info",
  // Connatix
  "connatix.com",
  // Outstream
  "unrulymedia.com",
  "unruly.co",
  // Verve
  "verve.com",
  "gssprt.jp",
  // AudienceScience
  "reachlocal.com",
  // Zaraz
  "zaraz.cloudflare.com",
  // ReSci
  "retentionscience.com",
  // Searchanise
  "searchanise.io",
]);

// URL substring patterns (applied to full URL)
const BLOCKED_URL_PATTERNS = [
  "/pagead/",
  "/adsbygoogle",
  "/googletag/",
  "prebid.",
  "prebid/",
  "header-bid",
  "headerBid",
  "/rtb/",
  "/openrtb/",
  "/ads/tracking",
  "/ads/pixel",
  "/ad/impression",
  "/adimpression",
  "/adserver",
  "/adsystem",
  "/adtrack",
  "/adframe",
  "/adunit",
  "/adcode",
  "/tracking/pixel",
  "/tracking/event",
  "/tracker/",
  "/pixel.gif",
  "/pixel.png",
  "/pixel?",
  "/1x1.gif",
  "/1x1.png",
  "/beacon.gif",
  "/beacon?",
  "/telemetry/",
  "/analytics/collect",
  "/collect/v1/",
  "/t.gif",
  "/t.js",
  "/ga.js",
  "/gtag/js",
  "/gtm.js",
  "/analytics.js",
  "/fbevents.js",
  "/fbpixel",
  "/track?",
  "/track.php",
  "/tracking.php",
  "/impression.php",
  "/impression?",
  "/log?",
  "/log.gif",
  "/ping?",
  "/ping.gif",
  "/stats?",
  "/stat.php",
  "/counter?",
  "/counter.gif",
];

// Cosmetic filter selectors for DOM element hiding
const COSMETIC_SELECTORS = [
  // Generic ad containers
  "[id^='google_ads_iframe']",
  "[id^='div-gpt-ad']",
  "[id^='ad-slot']",
  "[id^='adunit']",
  "[class^='adsbygoogle']",
  "[data-ad-slot]",
  "[data-ad-unit-path]",
  "[data-ad-client]",
  // Ad iframes
  "iframe[src*='doubleclick.net']",
  "iframe[src*='googlesyndication.com']",
  "iframe[src*='googleadservices.com']",
  "iframe[src*='outbrain.com']",
  "iframe[src*='taboola.com']",
  "iframe[src*='criteo.com']",
  "iframe[src*='amazon-adsystem.com']",
  // Sponsored / native ad blocks
  "[aria-label='Ads']",
  "[aria-label='Advertisement']",
  "[data-testid='ad-unit']",
  "[class*='sponsored-content']",
  "[class*='sponsored-post']",
  "[id*='sponsored']",
  // Social trackers
  ".fb-like-box",
  ".fb-page",
  // Push notification prompts (common patterns)
  "[class*='push-notification-prompt']",
  "[class*='push-prompt']",
  "[id*='push-prompt']",
];
