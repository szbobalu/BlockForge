// content.js - BlockForge cosmetic filter engine
// Runs at document_start to hide ad elements before paint

(function () {
  'use strict';

  // Inject hide rules immediately via a style element
  function injectCosmeticCSS() {
    if (!COSMETIC_SELECTORS || COSMETIC_SELECTORS.length === 0) return;
    try {
      const style = document.createElement('style');
      style.id = 'blockforge-cosmetic';
      style.textContent = COSMETIC_SELECTORS.join(', ') + ' { display: none !important; visibility: hidden !important; }';
      (document.head || document.documentElement).appendChild(style);
    } catch (_) {}
  }

  // Extra known ad element patterns (host-independent)
  const EXTRA_PATTERNS = [
    'ins.adsbygoogle',
    '[id^="banner_ad"]',
    '[id^="ad_banner"]',
    '[class^="ad-banner"]',
    '[class*="google-ad"]',
    '[class*="mgbox"]',
    '[id*="adbanner"]',
    '[id*="ad-container"]',
    '[class*="ad-container"]',
    '[id*="ad-wrapper"]',
    '[class*="ad-wrapper"]',
    '[data-ad-format]',
    '[data-widget-type="ad"]',
    '.OUTBRAIN',
    '#taboola-below-article-thumbnails',
    '#taboola-above-article-thumbnails',
    '.trc_related_container',
    '[id^="rc_widget"]',
    '.criteo-sponsored-products',
    '[class*="criteo"]',
  ];

  function injectExtraCSS() {
    try {
      const style = document.getElementById('blockforge-extra');
      if (style) return;
      const el = document.createElement('style');
      el.id = 'blockforge-extra';
      el.textContent = EXTRA_PATTERNS.join(', ') + ' { display: none !important; }';
      (document.head || document.documentElement).appendChild(el);
    } catch (_) {}
  }

  // MutationObserver to catch dynamically injected ad elements
  function observeDOM() {
    const allSelectors = (COSMETIC_SELECTORS || []).concat(EXTRA_PATTERNS);
    const combined = allSelectors.join(', ');

    const observer = new MutationObserver(mutations => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== 1) continue;
          try {
            if (node.matches && node.matches(combined)) {
              node.style.setProperty('display', 'none', 'important');
            }
            const children = node.querySelectorAll(combined);
            children.forEach(el => el.style.setProperty('display', 'none', 'important'));
          } catch (_) {}
        }
      }
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  injectCosmeticCSS();
  injectExtraCSS();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', observeDOM, { once: true });
  } else {
    observeDOM();
  }
})();
