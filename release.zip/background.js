// background.js - BlockForge request interceptor and stats engine

// --- state ---

let state = {
  enabled: true,
  stats: {
    total: 0,
    ads: 0,
    trackers: 0,
    sessions: 0,
    byTab: {}
  }
};

// --- init ---

browser.storage.local.get(['enabled', 'stats']).then(stored => {
  if (stored.enabled !== undefined) state.enabled = stored.enabled;
  if (stored.stats) {
    // Restore totals but clear per-tab (stale after restart)
    state.stats.total = stored.stats.total || 0;
    state.stats.ads = stored.stats.ads || 0;
    state.stats.trackers = stored.stats.trackers || 0;
    state.stats.sessions = (stored.stats.sessions || 0) + 1;
    state.stats.byTab = {};
  } else {
    state.stats.sessions = 1;
  }
  browser.storage.local.set({ stats: state.stats, sessions: state.stats.sessions });
  syncBadge();
});

// --- blocking logic ---

function getHostname(url) {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, '');
  } catch (_) {
    return '';
  }
}

function classifyRequest(url, hostname) {
  // Check ad domains first (higher priority label)
  if (AD_DOMAINS.has(hostname)) return 'ad';
  for (const domain of AD_DOMAINS) {
    if (hostname.endsWith('.' + domain)) return 'ad';
  }
  if (TRACKER_DOMAINS.has(hostname)) return 'tracker';
  for (const domain of TRACKER_DOMAINS) {
    if (hostname.endsWith('.' + domain)) return 'tracker';
  }
  // URL pattern fallback
  for (const pattern of BLOCKED_URL_PATTERNS) {
    if (url.includes(pattern)) return 'ad';
  }
  return null;
}

function shouldBlock(url, hostname) {
  if (!state.enabled) return false;
  if (!url || !hostname) return false;
  // Exact or subdomain match against ad domains
  if (AD_DOMAINS.has(hostname)) return true;
  for (const domain of AD_DOMAINS) {
    if (hostname.endsWith('.' + domain)) return true;
  }
  // Exact or subdomain match against tracker domains
  if (TRACKER_DOMAINS.has(hostname)) return true;
  for (const domain of TRACKER_DOMAINS) {
    if (hostname.endsWith('.' + domain)) return true;
  }
  // URL pattern match
  for (const pattern of BLOCKED_URL_PATTERNS) {
    if (url.includes(pattern)) return true;
  }
  return false;
}

browser.webRequest.onBeforeRequest.addListener(
  details => {
    if (!state.enabled) return { cancel: false };

    const hostname = getHostname(details.url);
    if (!shouldBlock(details.url, hostname)) return { cancel: false };

    const type = classifyRequest(details.url, hostname);
    const tabId = details.tabId;

    state.stats.total++;
    if (type === 'ad') state.stats.ads++;
    else state.stats.trackers++;

    if (tabId > 0) {
      if (!state.stats.byTab[tabId]) {
        state.stats.byTab[tabId] = { total: 0, ads: 0, trackers: 0, hostname: '', lastSeen: [] };
      }
      const t = state.stats.byTab[tabId];
      t.total++;
      if (type === 'ad') t.ads++;
      else t.trackers++;
      // Keep a rolling list of last 8 blocked hostnames for the tab
      t.lastSeen = [{ hostname, type, ts: Date.now() }, ...t.lastSeen].slice(0, 8);
    }

    persistStats();
    syncBadge();

    return { cancel: true };
  },
  { urls: ['<all_urls>'] },
  ['blocking']
);

// --- tab tracking ---

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url) {
    const hostname = getHostname(tab.url);
    if (!state.stats.byTab[tabId]) {
      state.stats.byTab[tabId] = { total: 0, ads: 0, trackers: 0, hostname, lastSeen: [] };
    } else {
      // New page load on same tab - reset tab stats but keep hostname updated
      if (state.stats.byTab[tabId].hostname !== hostname) {
        state.stats.byTab[tabId] = { total: 0, ads: 0, trackers: 0, hostname, lastSeen: [] };
      }
    }
  }
});

browser.tabs.onRemoved.addListener(tabId => {
  delete state.stats.byTab[tabId];
});

// --- badge ---

function syncBadge() {
  const count = state.stats.total;
  const label = !state.enabled ? 'OFF' : count >= 10000 ? '10k+' : String(count);
  const color = !state.enabled ? '#555555' : '#00cc66';
  browser.browserAction.setBadgeText({ text: label });
  browser.browserAction.setBadgeBackgroundColor({ color });
}

// --- persistence ---

let persistTimer = null;
function persistStats() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    browser.storage.local.set({ stats: state.stats, enabled: state.enabled });
  }, 800);
}

// --- message bus ---

browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case 'getState': {
      browser.tabs.query({ active: true, currentWindow: true }).then(tabs => {
        const activeTab = tabs[0];
        const tabStats = activeTab ? state.stats.byTab[activeTab.id] || null : null;
        const tabHostname = activeTab ? getHostname(activeTab.url || '') : '';
        sendResponse({
          enabled: state.enabled,
          stats: {
            total: state.stats.total,
            ads: state.stats.ads,
            trackers: state.stats.trackers,
            sessions: state.stats.sessions,
          },
          tabStats: tabStats ? {
            total: tabStats.total,
            ads: tabStats.ads,
            trackers: tabStats.trackers,
            hostname: tabStats.hostname || tabHostname,
            lastSeen: tabStats.lastSeen || [],
          } : {
            total: 0, ads: 0, trackers: 0,
            hostname: tabHostname,
            lastSeen: [],
          }
        });
      });
      return true; // async
    }

    case 'toggle': {
      state.enabled = !state.enabled;
      persistStats();
      syncBadge();
      sendResponse({ enabled: state.enabled });
      break;
    }

    case 'resetStats': {
      state.stats = { total: 0, ads: 0, trackers: 0, sessions: state.stats.sessions, byTab: {} };
      persistStats();
      syncBadge();
      sendResponse({ ok: true });
      break;
    }

    case 'getRulesCount': {
      sendResponse({ ads: AD_DOMAINS.size, trackers: TRACKER_DOMAINS.size, patterns: BLOCKED_URL_PATTERNS.length });
      break;
    }
  }
  return false;
});
